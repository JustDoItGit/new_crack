1) Replace Dll
2) Go to menu HELP
3) Click Register
4) Insert this Serial : NAVH-6A37-URL3-BXES
5) Click Activate
6) Restart Sw..

Enjoy
=================
www.downloadly.ir